<?php
// backward compatible for ~1.4
Arkhe::get_part( 'single/foot/prev_next_link', $args );

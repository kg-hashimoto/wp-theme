<?php
/* Template Name: 企業ページ*/
get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php
$company_name = get_post_meta(get_the_ID(), '企業名' , true);
$company_district = get_post_meta(get_the_ID(), '地区', true);
$business_summary= get_post_meta(get_the_ID(), '主な事業内容',true);
$work_emotion = get_post_meta(get_the_ID(), '働きやすさ・やりがい',true);
$rec1_style = get_post_meta(get_the_ID(), '雇用形態1',true);
$rec1_name = get_post_meta(get_the_ID(), '業種1',true);
$rec1_place = get_post_meta(get_the_ID(), '勤務地1' , true);
$rec1_detail = get_post_meta(get_the_ID(), '仕事の内容1' , true);

$rec2_style = get_post_meta(get_the_ID(), '雇用形態2',true);
$rec2_name = get_post_meta(get_the_ID(), '業種2',true);
$rec2_place = get_post_meta(get_the_ID(), '勤務地2' , true);
$rec2_detail = get_post_meta(get_the_ID(), '仕事の内容2' , true);
$open2 = get_post_meta(get_the_ID(),'公開設定2' , true);

$rec3_style = get_post_meta(get_the_ID(), '雇用形態3',true);
$rec3_name = get_post_meta(get_the_ID(), '業種3',true);
$rec3_place = get_post_meta(get_the_ID(), '勤務地3' , true);
$rec3_detail = get_post_meta(get_the_ID(), '仕事の内容3' , true);
$open3 = get_post_meta(get_the_ID(),'公開設定3' , true);

?>

<div style="background-color:whitesmoke;width:100%;">
<h2>企業情報</h2>
<section class="company-info">
  <div class="company-summary">
	  <div class="district"><?php echo esc_html($company_district); ?></div>  <div class="company-name"><?php echo esc_html($company_name); ?></div>
	  
  </div>
  <div class="company-detail">
	  <div class="company-image" style="background-image:url(http://hiroshima-test.1detukureru.com/wp-content/uploads/2023/04/3865982_l_720.jpg)"></div>
	  <div class="company-document">
		  <div class="main-business">
			  <span class="blue-line">主な事業内容</span><br>
			  <?php echo $business_summary; ?></div>
		  <div class="work-emotion">
			  <span class="blue-line">働きやすさ・やりがい</span><br>
<?php echo $work_emotion; ?>
		  　　</div>
	  
	  </div>
	</div>
</section>
<h2>求人情報</h2>
<div class="recruit-container">
<section class="recruit">
	<div class="recruit-summary">
		<span class="blue-box"><?php 
			if($rec1_style == 'option_1'){
				echo '正社員';
			}elseif($rec1_style == 'option_2'){
				echo '契約社員';
			}elseif($rec1_style == 'option_3'){
				echo '派遣社員';
			}elseif($rec1_style == 'option_4'){
				echo 'アルバイト';
			}elseif($rec1_style == 'option_5'){
				echo 'パート';
			}elseif($rec1_style == 'option_6'){
				echo '業務委託';
			}elseif($rec1_style == 'option_7'){
				echo 'その他';
			}		
			 ?></span>
		<span class="recruit-name"><?php echo esc_html($rec1_name); ?></span><br><br>
		<span class="white-box">勤務地</span>
		<span class="recruit-district"><?php echo esc_html($rec1_place);  ?></span>
	</div>

	<div class="recruit-detail">
		<p>
<?php echo $rec1_detail; ?>
		</p>
	
	</div>
</section>
<?php if($open2 == 'option_2'){ ?>
<section class="recruit">
	<div class="recruit-summary">
		<span class="blue-box"><?php 
			if($rec2_style == 'option_1'){
				echo '正社員';
			}elseif($rec2_style == 'option_2'){
				echo '契約社員';
			}elseif($rec2_style == 'option_3'){
				echo '派遣社員';
			}elseif($rec2_style == 'option_4'){
				echo 'アルバイト';
			}elseif($rec2_style == 'option_5'){
				echo 'パート';
			}elseif($rec2_style == 'option_6'){
				echo '業務委託';
			}elseif($rec2_style == 'option_7'){
				echo 'その他';
			}		
			 ?></span>
		<span class="recruit-name"><?php echo esc_html($rec2_name); ?></span><br><br>
		<span class="white-box">勤務地</span>
		<span class="recruit-district"><?php echo esc_html($rec2_place);  ?></span>
	</div>

	<div class="recruit-detail">
		<p>
<?php echo $rec2_detail; ?>
		</p>
	
	</div>
</section>
<?php } ?><?php if($open3 == 'option_2'){ ?>
<section class="recruit">
	<div class="recruit-summary">
		<span class="blue-box"><?php 
			if($rec3_style == 'option_1'){
				echo '正社員';
			}elseif($rec3_style == 'option_2'){
				echo '契約社員';
			}elseif($rec3_style == 'option_3'){
				echo '派遣社員';
			}elseif($rec3_style == 'option_4'){
				echo 'アルバイト';
			}elseif($rec3_style == 'option_5'){
				echo 'パート';
			}elseif($rec3_style == 'option_6'){
				echo '業務委託';
			}elseif($rec3_style == 'option_7'){
				echo 'その他';
			}		
			 ?></span>
		<span class="recruit-name"><?php echo esc_html($rec3_name); ?></span><br><br>
		<span class="white-box">勤務地</span>
		<span class="recruit-district"><?php echo esc_html($rec3_place);  ?></span>
	</div>

	<div class="recruit-detail">
		<p>
<?php echo $rec3_detail; ?>
		</p>
	
	</div>
</section><?php } ?>

<?php endwhile; endif; ?>
<br><br><br></div><section class="postcontent">
<?php the_content(); ?>
	</section>		</div><br><br>


<style>

	.company-info{
		width:calc(100% - 60px);
		padding:10px;
		margin:20px auto;
		border:solid 0.5px gray;
		box-shadow:5px 5px;
		background-color:white;

	}
	.company-image{
	
		width:360px;
		height:270px;
		
	}
	.district{
		width:90px;
		height:35px;
		background-color:orange;
		color:white;
		text-align:center;
		font-size:1.2em;
		line-height:35px;
		display:inline-block;
	}
	.company-name{
		display:inline-block;
		height:35px;
		font-size:1.2em;
		line-height:35px;
	}
	.company-detail{
		margin-top:10px;
		width:100%;
	}
	
	.company-image{
		display:inline-block;
		vertical-align:top;
		background-size:cover;
		margin-right:10px;
	}
	.company-document{
		display:inline-block;
		vertical-align:top;
		width:calc(100% - 380px) ;
	}
	.blue-line{
		display:inline-block;
		background-color:royalblue;
		color:white;
		font-size:1.1em;
		width:200px;
		padding:4px 0px;
		margin-bottom:4px;
		text-align:center;
	}
	.main-business{
		margin-bottom:10px;
	}
	.recruit{
		border:solid 1px gray;
		margin-top:10px;
		width:100%;
		min-height:130px;
padding:10px;
		width:370px;
		height:460px;
		display:inline-block;
		margin-left:1vw;
		margin-right:1vw;
		box-shadow:4px 4px;
		background-color:white;
		
	}
	.recruit-container{
	
		max-width:1200px;
		margin: 0 auto;
	}
	@media(max-width:1200px){
		.recruit-container{
			max-width:800px;}
	}
	@media(max-width:800px){
		.recruit-container{
			max-width:400px;
		}
	}
	.recruit-summary{
		width:370px;
		display:inline-block;
	}
	.recruit-detail{
	    width:100% ;
		display:inline-block;
		vertical-align:top;
	}
	.blue-box{
		display:inline-block;
		background-color:royalblue;
		color:white;
		font-size:1em;
		width:100px;
		height:30px;
		text-align:center;
		line-height:30px;
		vertical-align:top;
	}
	.recruit-name{
		display:inline-block;
		font-size:1.3em;

        vertical-align:top;
		line-height:30px;
	}
	.white-box{
		width:100px;
		height:30px;
		border:solid royalblue 2px;
		display:inline-block;
		font-size:1em;
		text-align:center;
		line-height:30px;
	}
	.recruit-district{
				display:inline-block;
		font-size:1.3em;

        vertical-align:top;
		line-height:30px;
	}	h2{
	text-align:center;
	width:100%;
	display:inline-block;
	margin-top:10px;
	
}
	h2:after{
		content:"";
		display:block;
		width:100px;
	
		height:4px;
		margin:0 auto;
		margin-bottom:6px;
		background-color:royalblue;
	}
	.postcontent{
		width:100%;
		padding:10px;
	}
</style>
<?php get_footer(); ?>
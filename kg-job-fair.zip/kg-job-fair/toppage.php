<?php
/**
 * フロントページテンプレート
 */
get_header(); ?>
<main id="main_content" class="<?php Arkhe::main_class(); ?>">
	<div class="<?php Arkhe::main_body_class(); ?>">
		<?php
			do_action( 'arkhe_start_front_main' );

			if ( is_home() ) :
				do_action( 'arkhe_before_home_content' );
				Arkhe::get_part( 'home' );
				do_action( 'arkhe_after_home_content' );
			else :
				do_action( 'arkhe_before_front_content' );
				while ( have_posts() ) :
					the_post();
					Arkhe::get_part( 'front' );
				endwhile;
				do_action( 'arkhe_after_front_content' );
			endif;

			do_action( 'arkhe_end_front_main' );
		?>
	</div>
	<div class ="topcontent">
       <h2>呉地区製鉄業関係従業員などを対象とした</h2>
	   <h1>合同企業面接会</h1>
	   <div class="top-futures">
		  <div class="top-future">
			服装自由
		  </div>
		  <div class="top-future">
			入退場自由
		  </div>
		  <div class="top-future">個別相談ブースあり(予約制)</div>
	   </div>
	 
	</div>
	<style>
     .topcontent{
		width:100%;
		height:700px;
		background-image:url("https://cdn.pixabay.com/photo/2013/02/21/19/10/sea-84629_960_720.jpg");
	 }

	</style>
</main>
<?php
get_footer();

const { registerBlockType } = wp.blocks;
const { RichText } = wp.editor;

registerBlockType('mytheme/myblock', {
    title: 'My Custom Block',
    icon: 'smiley',
    category: 'common',
    attributes: {
        contentOne: {
            type: 'string',
            source: 'html',
            selector: 'span',
        },
        contentTwo: {
            type: 'string',
            source: 'html',
            selector: 'p',
        },
    },
    edit: ({ attributes, setAttributes }) => {
        const { contentOne, contentTwo } = attributes;

        function onChangeContentOne(newContentOne) {
            setAttributes({ contentOne: newContentOne });
        }

        function onChangeContentTwo(newContentTwo) {
            setAttributes({ contentTwo: newContentTwo });
        }

        return (
            <div>
                <RichText
                    tagName="span"
                    value={contentOne}
                    onChange={onChangeContentOne}
                />
                <RichText
                    tagName="p"
                    value={contentTwo}
                    onChange={onChangeContentTwo}
                />
            </div>
        );
    },
    save: ({ attributes }) => {
        const { contentOne, contentTwo } = attributes;

        return (
            <div>
                <RichText.Content tagName="span" value={contentOne} />
                <RichText.Content tagName="p" value={contentTwo} />
            </div>
        );
    },
});
<?php
namespace Arkhe_Theme\Update;

/**
 * アップデート処理
 */


}

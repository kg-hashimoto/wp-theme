jQuery(document).ready(function ($) {
    var file_frame;

    $(document).on('click', '.image-upload-button', function (e) {
        e.preventDefault();

        var input_field = $(this).prev('.image-upload-field');
        var preview_element = $(this).next('#image-preview').find('img');

        if (file_frame) {
            file_frame.open();
            return;
        }

        file_frame = wp.media.frames.file_frame = wp.media({
            title: 'Select Image',
            button: {
                text: 'Select Image',
            },
            multiple: false,
        });

        file_frame.on('select', function () {
            var attachment = file_frame.state().get('selection').first().toJSON();
            input_field.val(attachment.url);
            preview_element.attr('src', attachment.url);
        });

        file_frame.open();
    });
});

<?php
/**
 * for ~1.4
 */
?>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="c-headLogo" rel="home" style="font-size:1.5em">
	<?php echo esc_html( get_option( 'blogname' ) ); ?>
</a>

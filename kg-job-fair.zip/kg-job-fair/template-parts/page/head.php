<?php
// backward compatible for ~1.4
Arkhe::get_part( 'page/title', $args );

<?php
/**
 * @package Arkhe
 * @author LOOS,Inc.
 * @link https://arkhe-theme.com/
 */

/**
 * パス・URIの定数化
 */
define( 'ARKHE_THEME_PATH', get_template_directory() );
define( 'ARKHE_THEME_URI', get_template_directory_uri() );

// 子テーマ用のパス, URI
if ( ! defined( 'ARKHE_CHILD_PATH' ) ) {
	define( 'ARKHE_CHILD_PATH', get_stylesheet_directory() );
}
if ( ! defined( 'ARKHE_CHILD_URI' ) ) {
	define( 'ARKHE_CHILD_URI', get_stylesheet_directory_uri() );
}


/**
 * 翻訳の読み込み
 */
load_theme_textdomain( 'arkhe', ARKHE_THEME_PATH . '/languages' );


/**
 * CLASSのオートロード
 */
spl_autoload_register(
	function( $classname ) {

		// 名前に Arkhe_Theme がなければオートロードしない。
		if ( strpos( $classname, 'Arkhe_Theme' ) === false ) return;

		$classname = str_replace( '\\', '/', $classname );
		$classname = str_replace( 'Arkhe_Theme/', '', $classname );
		$file      = ARKHE_THEME_PATH . '/classes/' . $classname . '.php';

		if ( file_exists( $file ) ) require $file;
	}
);


/**
 * Arkhe_Theme
 */
class Arkhe extends \Arkhe_Theme\Data {

	use \Arkhe_Theme\Utility\Attrs,
		\Arkhe_Theme\Utility\Get,
		\Arkhe_Theme\Utility\SVG,
		\Arkhe_Theme\Utility\Image,
		\Arkhe_Theme\Utility\Parts,
		\Arkhe_Theme\Utility\Output,
		\Arkhe_Theme\Utility\Licence,
		\Arkhe_Theme\Utility\Condition;

	public function __construct() {

		// データをセット
		self::init();

		// 定数定義
		require_once ARKHE_THEME_PATH . '/inc/consts.php';

		// テーマサポート機能
		require_once ARKHE_THEME_PATH . '/inc/theme_support.php';

		// ファイル読み込み
		require_once ARKHE_THEME_PATH . '/inc/enqueue_scripts.php';

		// カスタマイザー
		require_once ARKHE_THEME_PATH . '/inc/customizer.php';

		// カスタムメニュー
		require_once ARKHE_THEME_PATH . '/inc/custom_menu.php';

		// ウィジェット
		require_once ARKHE_THEME_PATH . '/inc/widget.php';

		// Gutenberg
		require_once ARKHE_THEME_PATH . '/inc/gutenberg.php';

		// クラシックエディター
		require_once ARKHE_THEME_PATH . '/inc/tinymce.php';

		// プラガブル関数
		require_once ARKHE_THEME_PATH . '/inc/pluggable.php';

		// 出力処理
		require_once ARKHE_THEME_PATH . '/inc/output.php';

		// その他、フック処理
		require_once ARKHE_THEME_PATH . '/inc/hooks.php';

		// 後方互換用関数
		require_once ARKHE_THEME_PATH . '/inc/backward.php';



		// アップデート時の処理

	}
}
function enqueue_media_uploader() {
    if (is_admin()) {
        wp_enqueue_media();
        wp_enqueue_script('media-uploader', get_template_directory_uri() . '/js/media-uploader.js', array('jquery'));
    }
}
add_action('admin_enqueue_scripts', 'enqueue_media_uploader');

//カスタムグローバルナビゲーション
function register_my_gnav() {
	register_nav_menu( 'my_gnav', __( 'My Global Navigation', 'your-theme-text-domain' ) );
}


//よくある質問
/* ---------- カスタム投稿タイプを追加 ---------- */
add_action( 'init', 'create_post_type' );

function create_post_type() {

  register_post_type(
    'faq',
    array(
'label' => '【KG】FAQ',
      'public' => true,
      'has_archive' => true,
      'show_in_rest' => true,
      'menu_position' => 2,
	  'menu_icon' => 'dashicons-art',
      'supports' => array(
        'title',
        'editor',
        'thumbnail',
        'revisions',
      ),
    )
  );

}

/* ---------- カスタム投稿タイプを追加 ---------- */
add_action( 'init', 'create_post_type2' );

function create_post_type2() {

  register_post_type(
    'consul',
    array(
'label' => '【KG】相談ｺｰﾅｰ',
      'public' => true,
      'has_archive' => true,
      'show_in_rest' => true,
      'menu_position' => 2,
	  'menu_icon' => 'dashicons-art',
      'supports' => array(
        'title',
        'editor',
        'thumbnail',
        'revisions',
      ),
    )
  );

}




add_action( 'after_setup_theme', 'register_my_gnav' );

function create_my_custom_post_type() {
    register_post_type('my_custom_post',
        array(
            'labels' => array(
                'name' => __('【KG】企業一覧'),
                'singular_name' => __('企業')
            ),
            'public' => true,
            'menu_icon' => 'dashicons-art',
            'menu_position' => 1,
            'has_archive' => true,
			'show_in_rest' => true, // Enable Gutenberg Editor
            'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
            'rewrite' => array(
                'slug' => 'companies', // ここで任意のスラッグを設定
                'with_front' => false, // フロントを含むかどうか
            ),
        )
    );
    register_taxonomy(
        'my_custom_category',
        'my_custom_post',
        array(
            'label' => __('面接会'),
            'rewrite' => array('slug' => 'meetups'),
            'hierarchical' => true,
            'show_admin_column' => true
        )
    );

    // Add post_tag taxonomy (default tags) to my_custom_post post type
    register_taxonomy_for_object_type('post_tag', 'my_custom_post');
}
add_action('init', 'create_my_custom_post_type');
// カスタムフィールドの表示を追加する関数
function my_custom_category_dropdown_field($term) {
    // カスタムフィールドの値を取得します
    $selected_option = get_term_meta($term->term_id, 'my_custom_dropdown_field', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="my_custom_dropdown_field">対面orオンライン</label></th>
        <td>
            <select name="my_custom_dropdown_field" id="my_custom_dropdown_field">
                <option value="option1" <?php selected($selected_option, 'option1'); ?>>対面</option>
                <option value="option2" <?php selected($selected_option, 'option2'); ?>>オンライン</option>
            </select>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_category_dropdown_field', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_category_dropdown_field', 10, 2);
// カスタムフィールドのデータを保存する関数
function save_my_custom_category_dropdown_field($term_id) {
    if (isset($_POST['my_custom_dropdown_field'])) {
        update_term_meta($term_id, 'my_custom_dropdown_field', sanitize_text_field($_POST['my_custom_dropdown_field']));
    }
}
add_action('edited_my_custom_category', 'save_my_custom_category_dropdown_field', 10, 2);
add_action('create_my_custom_category', 'save_my_custom_category_dropdown_field', 10, 2);

function my_custom_category_add_fields($term) {
    $custom_field_value = get_term_meta($term->term_id, 'my_custom_field', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_field"><?php _e('会場名orオンラインツール名'); ?></label>
        </th>
        <td>
            <input type="text" name="my_custom_field" id="my_custom_field" value="<?php echo esc_attr($custom_field_value); ?>" />
            <p class="description"><?php _e('会場名またはオンラインツール名を入れてください。改行する位置には&lt;br&gt;と入れてください'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_category_add_fields', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_category_add_fields', 10, 2);
function my_custom_category_save_fields($term_id) {
    if (isset($_POST['my_custom_field'])) {
        update_term_meta($term_id, 'my_custom_field', $_POST['my_custom_field']);
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_fields', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_fields', 10, 2);






function my_custom_second_category_add_fields($term) {
$custom_second_field_value = get_term_meta($term->term_id, 'my_custom_second_field', true);
   ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_second_field"><?php _e('GoogleマップURL'); ?></label>
        </th>
        <td>
            <input type="text" name="my_custom_second_field" id="my_custom_second_field" value="<?php echo esc_attr($custom_second_field_value); ?>" />
            <p class="description"><?php _e('GoogleMapのURLを入れてください'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_second_category_add_fields', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_second_category_add_fields', 10, 2);
function my_custom_category_save_second_fields($term_id) {
    if (isset($_POST['my_custom_second_field'])) {
        update_term_meta($term_id, 'my_custom_second_field', sanitize_text_field($_POST['my_custom_second_field']));
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_second_fields', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_second_fields', 10, 2);


function my_custom_third_category_add_fields($term) {
$custom_third_field_value = get_term_meta($term->term_id, 'my_custom_third_field', true);
   ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_third_field"><?php _e('カスタム日程'); ?></label>
        </th>
        <td>
            <input type="text" name="my_custom_third_field" id="my_custom_third_field" value="<?php echo esc_attr($custom_third_field_value); ?>" />
            <p class="description"><?php _e('「●月頃」「未定」のような表記'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_third_category_add_fields', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_third_category_add_fields', 10, 2);
function my_custom_category_save_third_fields($term_id) {
    if (isset($_POST['my_custom_third_field'])) {
        update_term_meta($term_id, 'my_custom_third_field', $_POST['my_custom_third_field']);
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_third_fields', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_third_fields', 10, 2);










function my_custom_category_add_date_field($term) {
    $custom_date_value = get_term_meta($term->term_id, 'my_custom_date', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_date"><?php _e('実施日'); ?></label>
        </th>
        <td>
            <input type="date" name="my_custom_date" id="my_custom_date" value="<?php echo esc_attr($custom_date_value); ?>" />
            <p class="description"><?php _e('面接会の日程を入力してください'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_category_add_date_field', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_category_add_date_field', 10, 2);
function my_custom_category_save_date_field($term_id) {
    if (isset($_POST['my_custom_date'])) {
        update_term_meta($term_id, 'my_custom_date', sanitize_text_field($_POST['my_custom_date']));
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_date_field', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_date_field', 10, 2);
function my_custom_category_add_time_field($term) {
    $custom_time_value = get_term_meta($term->term_id, 'my_custom_time', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_time"><?php _e('開始時間'); ?></label>
        </th>
        <td>
            <input type="time" name="my_custom_time" id="my_custom_time" value="<?php echo esc_attr($custom_time_value); ?>" />
            <p class="description"><?php _e('面接会の開始時間を入力してください'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_category_add_time_field', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_category_add_time_field', 10, 2);

function my_custom_category_save_time_field($term_id) {
    if (isset($_POST['my_custom_time'])) {
        update_term_meta($term_id, 'my_custom_time', sanitize_text_field($_POST['my_custom_time']));
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_time_field', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_time_field', 10, 2);
function my_custom_category_add_second_time_field($term) {
    $custom_second_time_value = get_term_meta($term->term_id, 'my_custom_second_time', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="my_custom_second_time"><?php _e('終了時間'); ?></label>
        </th>
        <td>
            <input type="time" name="my_custom_second_time" id="my_custom_second_time" value="<?php echo esc_attr($custom_second_time_value); ?>" />
            <p class="description"><?php _e('面接会の終了時間を入力してください'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('my_custom_category_edit_form_fields', 'my_custom_category_add_second_time_field', 10, 2);
add_action('my_custom_category_add_form_fields', 'my_custom_category_add_second_time_field', 10, 2);
function my_custom_category_save_second_time_field($term_id) {
    if (isset($_POST['my_custom_second_time'])) {
        update_term_meta($term_id, 'my_custom_second_time', sanitize_text_field($_POST['my_custom_second_time']));
    }
}
add_action('edited_my_custom_category', 'my_custom_category_save_second_time_field', 10, 2);
add_action('create_my_custom_category', 'my_custom_category_save_second_time_field', 10, 2);






function my_custom_category_add_detail1_field($term){
	$custom_detail1_value = get_term_meta($term->term_id , 'my_custom_detail1', true);
	?>

<tr><td>	<label for = "my_custom_detail1"><?php _e('自由入力欄') ?></label></td>

<td>
<textarea id="my_custom_detail1" name="my_custom_detail1" cols="80" rows="40" ><?php echo esc_textarea($custom_detail1_value); ?>
	</textarea></td></tr>

<?php
}

add_action('my_custom_category_add_form_fields', 'my_custom_category_add_detail1_field' , 10 , 2);
add_action('my_custom_category_edit_form_fields', 'my_custom_category_add_detail1_field' , 10 , 2);

function my_custom_category_save_detail1_field($term_id){
	if (isset($_POST['my_custom_detail1'])){
		update_term_meta($term_id, 'my_custom_detail1',
$_POST['my_custom_detail1']);
	}
}
add_action('edited_my_custom_category','my_custom_category_save_detail1_field',10,2);
add_action('create_my_custom_category','my_custom_category_save_detail1_field',10,2);







//企業の情報登録画面
 
function my_custom_meta_box() {
    add_meta_box(
        'my_custom_meta_box_id',
'企業情報',
        'my_custom_meta_box_callback',
        'my_custom_post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'my_custom_meta_box');
function my_custom_meta_box_callback($post) {
    wp_nonce_field('my_custom_meta_box', 'my_custom_meta_box_nonce');
/**
 *     for ($i = 1; $i <= 5; $i++) {
        $value = get_post_meta($post->ID, 'my_custom_field_' . $i, true);
        
        echo '<label for="my_custom_field_' . $i . '">My Custom Field ' . $i . ': </label>';
        echo '<input type="text" id="my_custom_field_' . $i . '" name="my_custom_field_' . $i . '" value="' . esc_attr($value) . '" size="25" /><br />';
		
		
		
    }
 */    
// ドロップダウンのオプションを配列で定義
$dropdown_options = array(
'option_1' => get_theme_mod('dropdown_option2_1', '雇用形態が設定されていません'),
'option_2' => get_theme_mod('dropdown_option2_2', '雇用形態が設定されていません'),
'option_3' => get_theme_mod('dropdown_option2_3', '雇用形態が設定されていません'),
'option_4' => get_theme_mod('dropdown_option2_4', '雇用形態が設定されていません'),
'option_5' => get_theme_mod('dropdown_option2_5', '雇用形態が設定されていません'),
'option_6' => get_theme_mod('dropdown_option2_6', '雇用形態が設定されていません'),
'option_7' => get_theme_mod('dropdown_option2_7', '雇用形態が設定されていません'),
'option_8' => get_theme_mod('dropdown_option2_8', '雇用形態が設定されていません'),
'option_9' => get_theme_mod('dropdown_option2_9', '雇用形態が設定されていません'),
'option_10' => get_theme_mod('dropdown_option2_10', '雇用形態が設定されていません'),
);
$dropdown_options2 = array(
'option_1' => get_theme_mod('dropdown_option_1', '職種カテゴリが設定されていません'),
'option_2' => get_theme_mod('dropdown_option_2', '職種カテゴリが設定されていません'),
'option_3' => get_theme_mod('dropdown_option_3', '職種カテゴリが設定されていません'),
'option_4' => get_theme_mod('dropdown_option_4', '職種カテゴリが設定されていません'),
'option_5' => get_theme_mod('dropdown_option_5', '職種カテゴリが設定されていません'),
'option_6' => get_theme_mod('dropdown_option_6', '職種カテゴリが設定されていません'),
'option_7' => get_theme_mod('dropdown_option_7', '職種カテゴリが設定されていません'),
'option_8' => get_theme_mod('dropdown_option_8', '職種カテゴリが設定されていません'),
'option_9' => get_theme_mod('dropdown_option_9', '職種カテゴリが設定されていません'),
'option_10' => get_theme_mod('dropdown_option_10', '職種カテゴリが設定されていません'),
'option_11' => get_theme_mod('dropdown_option_11', '職種カテゴリが設定されていません'),
'option_12' => get_theme_mod('dropdown_option_12', '職種カテゴリが設定されていません'),
'option_13' => get_theme_mod('dropdown_option_13', '職種カテゴリが設定されていません'),
'option_14' => get_theme_mod('dropdown_option_14', '職種カテゴリが設定されていません'),
'option_15' => get_theme_mod('dropdown_option_15', '職種カテゴリが設定されていません'),
'option_16' => get_theme_mod('dropdown_option_16', '職種カテゴリが設定されていません'),
'option_17' => get_theme_mod('dropdown_option_17', '職種カテゴリが設定されていません'),
'option_18' => get_theme_mod('dropdown_option_18', '職種カテゴリが設定されていません'),
'option_19' => get_theme_mod('dropdown_option_19', '職種カテゴリが設定されていません'),
'option_20' => get_theme_mod('dropdown_option_20', '職種カテゴリが設定されていません'),	

);
$dropdown_options3 = array(
'option_1' => '公開しない',
'option_2' => '公開する',
);
	
	
$value = get_post_meta($post->ID, '企業名', true);
echo '<div style="display:inline-block;width:100px;"><label for="企業名">企業名</label></div>';
echo '<input type="text" id="企業名" name="企業名" value="' . esc_attr($value) . '" size="40" /><br /><br/>';
	
$value = get_post_meta($post->ID, '地区', true);
echo '<div style="display:inline-block;width:100px;"><label for="地区">地区</label></div>';
echo '<input type="text" id="地区" name="地区" value="' . esc_attr($value) . '" size="15" /><br /><br/>';

	
$textarea_value = get_post_meta($post->ID, '主な事業内容', true);
echo '<div style="width:100px;"><label for="主な事業内容">主な事業内容: </label></div>';
echo '<textarea id="主な事業内容" name="主な事業内容" value="' . esc_textarea($textarea_value) .'" cols="80" rows="5" />' . esc_textarea($textarea_value) .'</textarea><br /><br/>';
	
$textarea_value = get_post_meta($post->ID, '働きやすさ・やりがい', true);
echo '<div style="width:200px;"><label for="働きやすさ・やりがい">働きやすさ・やりがい: </label></div>';
echo '<textarea id="働きやすさ・やりがい" name="働きやすさ・やりがい" value="' . esc_attr($value) . '" cols="80" rows="7" />'. esc_textarea($textarea_value) .'</textarea><br /><br/>';

$image_field_name = "イメージ画像";
$image_value = get_post_meta($post->ID, 'my_image_field', true);

echo '<label for="my_image_field">' . $image_field_name . '　 </label>';
echo '<input type="text" id="my_image_field" name="my_image_field" value="' . esc_attr($image_value) . '" size="25" class="image-upload-field" />';
echo '<button type="button" class="image-upload-button">画像をアップロード</button>';
echo '<div id="image-preview" style="margin-top: 10px;"><img src="' . esc_attr($image_value) . '" style="max-width: 250px;"></div>';
echo '<h3>求人1</h3>';
// ドロップダウンの現在の値を取得
$dropdown_value = get_post_meta($post->ID, '雇用形態1', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="雇用形態1">雇用形態</label></div>';
echo '<select name="雇用形態1" id="雇用形態1">';

foreach ($dropdown_options as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
	
	
	
// ドロップダウンの現在の値を取得
$dropdown_value = get_post_meta($post->ID, '業種カテゴリ1', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="業種カテゴリ1">職種カテゴリ</label></div>';
echo '<select name="業種カテゴリ1" id="業種カテゴリ1">';

foreach ($dropdown_options2 as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
	
$value = get_post_meta($post->ID, '業種1', true);
echo '<div style="display:inline-block;width:100px;"><label for="業種1">職種: </label></div>';
echo '<input type="text" id="業種1" name="業種1" value="' . esc_attr($value) . '" size="40" /><br /><br/>';
	
$value = get_post_meta($post->ID, '勤務地1', true);
echo '<div style="display:inline-block;width:100px;"><label for="勤務地1">勤務地: </label></div>';
echo '<input type="text" id="勤務地1" name="勤務地1" value="' . esc_attr($value) . '" size="30" /><br /><br/>';
	
$value = get_post_meta($post->ID, '仕事の内容1', true);
echo '<div style="width:200px;"><label for="仕事の内容1">仕事の内容: </label></div>';
echo '<textarea id="仕事の内容1" name="仕事の内容1" value="' . esc_attr($value) . '" cols="80" rows="8" />' . esc_textarea($value) . '</textarea><br /><br/>';
	
	
echo '<h3>求人2</h3><br>';
	$dropdown_value = get_post_meta($post->ID, '公開設定2', true);
	echo '<div style="width:100px;display:inline-block;"><label for="公開設定2">公開設定</label></div>';
echo '<select name="公開設定2" id="公開設定2">';

foreach ($dropdown_options3 as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
$dropdown_value = get_post_meta($post->ID, '雇用形態2', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="雇用形態2">雇用形態</label></div>';
echo '<select name="雇用形態2" id="雇用形態2">';

foreach ($dropdown_options as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';

	// ドロップダウンの現在の値を取得
$dropdown_value = get_post_meta($post->ID, '業種カテゴリ2', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="業種カテゴリ2">職種カテゴリ</label></div>';
echo '<select name="業種カテゴリ2" id="業種カテゴリ2">';

foreach ($dropdown_options2 as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
	
	
	
$value = get_post_meta($post->ID, '業種2', true);
echo '<div style="display:inline-block;width:100px;"><label for="業種2">職種2: </label></div>';
echo '<input type="text" id="業種2" name="業種2" value="' . esc_attr($value) . '" size="40" /><br /><br/>';
	
$value = get_post_meta($post->ID, '勤務地2', true);
echo '<div style="display:inline-block;width:100px;"><label for="勤務地2">勤務地2: </label></div>';
echo '<input type="text" id="勤務地2" name="勤務地2" value="' . esc_attr($value) . '" size="30" /><br /><br/>';
	
$value = get_post_meta($post->ID, '仕事の内容2', true);
echo '<div style="width:200px;"><label for="仕事の内容2">仕事の内容: </label></div>';
echo '<textarea id="仕事の内容2" name="仕事の内容2" value="' . esc_attr($value) . '" cols="80" rows="8" />'. esc_textarea($value) .'</textarea><br /><br/>';
echo '<h3>求人3</h3><br>';
	$dropdown_value = get_post_meta($post->ID, '公開設定3', true);
echo '<div style="width:100px;display:inline-block;"><label for="公開設定3">公開設定</label></div>';
echo '<select name="公開設定3" id="公開設定3">';

foreach ($dropdown_options3 as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
$dropdown_value = get_post_meta($post->ID, '雇用形態3', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="雇用形態3">雇用形態</label></div>';
echo '<select name="雇用形態3" id="雇用形態3">';

foreach ($dropdown_options as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';

	// ドロップダウンの現在の値を取得
$dropdown_value = get_post_meta($post->ID, '業種カテゴリ3', true);

// ドロップダウンのラベルと選択肢を表示
echo '<div style="width:100px;display:inline-block;"><label for="業種カテゴリ3">職種カテゴリ</label></div>';
echo '<select name="業種カテゴリ3" id="業種カテゴリ3">';

foreach ($dropdown_options2 as $key => $option) {
    echo '<option value="' . $key . '"' . selected($dropdown_value, $key, false) . '>' . $option . '</option>';
}

echo '</select><br /><br />';
	
	
$value = get_post_meta($post->ID, '業種3', true);
echo '<div style="display:inline-block;width:100px;"><label for="業種3">職種3: </label></div>';
echo '<input type="text" id="業種3" name="業種3" value="' . esc_attr($value) . '" size="40" /><br /><br/>';
	
$value = get_post_meta($post->ID, '勤務地3', true);
echo '<div style="display:inline-block;width:100px;"><label for="勤務地3">勤務地3: </label></div>';
echo '<input type="text" id="勤務地3" name="勤務地3" value="' . esc_attr($value) . '" size="30" /><br /><br/>';
	
$value = get_post_meta($post->ID, '仕事の内容3', true);
echo '<div style="width:200px;"><label for="仕事の内容3">仕事の内容: </label></div>';
echo '<textarea id="仕事の内容3" name="仕事の内容3" value="' . esc_attr($value) . '" cols="80" rows="8" />'. esc_textarea($value) .'</textarea><br /><br/>';
	


}
function save_my_custom_meta_box_data($post_id) {
    if (!isset($_POST['my_custom_meta_box_nonce'])) {
        return;
    }

    if (!wp_verify_nonce($_POST['my_custom_meta_box_nonce'], 'my_custom_meta_box')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

/**    for ($i = 1; $i <= 5; $i++) {
        if (!isset($_POST['my_custom_field_' . $i])) {
            return;
        }

        $my_data = sanitize_text_field($_POST['my_custom_field_' . $i]);

        update_post_meta($post_id, 'my_custom_field_' . $i, $my_data);
    }
 */
if (!isset($_POST['企業名'])) {
return;
}

$my_data = sanitize_text_field($_POST['企業名']);

update_post_meta($post_id, '企業名', $my_data);

if (!isset($_POST['地区'])) {
return;
}

$my_data = sanitize_text_field($_POST['地区']);

update_post_meta($post_id, '地区', $my_data);
	
if (!isset($_POST['業種1'])) {
return;
}

$my_data = sanitize_text_field($_POST['業種1']);
update_post_meta($post_id, '業種1', $my_data);
	
	
if (!isset($_POST['業種2'])) {
return;
}

$my_data = sanitize_text_field($_POST['業種2']);

update_post_meta($post_id, '業種2', $my_data);

if (!isset($_POST['業種3'])) {
return;
}

$my_data = sanitize_text_field($_POST['業種3']);

update_post_meta($post_id, '業種3', $my_data);
	

if (!isset($_POST['勤務地1'])) {
return;
}

$my_data = sanitize_text_field($_POST['勤務地1']);

update_post_meta($post_id, '勤務地1', $my_data);

if (!isset($_POST['勤務地2'])) {
return;
}

$my_data = sanitize_text_field($_POST['勤務地2']);

update_post_meta($post_id, '勤務地2', $my_data);
	
if (!isset($_POST['勤務地3'])) {
return;
}

$my_data = sanitize_text_field($_POST['勤務地3']);

update_post_meta($post_id, '勤務地3', $my_data);
	
	
if (!isset($_POST['主な事業内容'])) {
return;
}

$textarea_data = sanitize_textarea_field($_POST['主な事業内容']);

update_post_meta($post_id, '主な事業内容', $textarea_data);
	
if (!isset($_POST['仕事の内容1'])) {
return;
}

$textarea_data = sanitize_textarea_field($_POST['仕事の内容1']);

update_post_meta($post_id, '仕事の内容1', $textarea_data);
	
if (!isset($_POST['仕事の内容2'])) {
return;
}

$textarea_data = sanitize_textarea_field($_POST['仕事の内容2']);

update_post_meta($post_id, '仕事の内容2', $textarea_data);
	
if (!isset($_POST['仕事の内容3'])) {
return;
}

$textarea_data = sanitize_textarea_field($_POST['仕事の内容3']);

update_post_meta($post_id, '仕事の内容3', $textarea_data);
	
	
if (!isset($_POST['働きやすさ・やりがい'])) {
return;
}

$textarea_data = sanitize_textarea_field($_POST['働きやすさ・やりがい']);

update_post_meta($post_id, '働きやすさ・やりがい', $textarea_data);	
	
if (!isset($_POST['雇用形態1'])) {
return;
}

$dropdown_data = $_POST['雇用形態1'];
update_post_meta($post_id, '雇用形態1', $dropdown_data);
	


$dropdown_data2 = $_POST['雇用形態2'];
update_post_meta($post_id, '雇用形態2', $dropdown_data2);
	

$dropdown_data3 = $_POST['雇用形態3'];
update_post_meta($post_id, '雇用形態3', $dropdown_data3);

$dropdown_data4 = $_POST['業種カテゴリ1'];
update_post_meta($post_id, '業種カテゴリ1', $dropdown_data4);

$dropdown_data5 = $_POST['業種カテゴリ2'];
update_post_meta($post_id, '業種カテゴリ2', $dropdown_data5);

$dropdown_data6 = $_POST['業種カテゴリ3'];
update_post_meta($post_id, '業種カテゴリ3', $dropdown_data6);
	
$dropdown_data7 = $_POST['公開設定2'];
update_post_meta($post_id, '公開設定2', $dropdown_data7);
		
$dropdown_data8 = $_POST['公開設定3'];
update_post_meta($post_id, '公開設定3', $dropdown_data8);


    $image_data = sanitize_text_field($_POST['my_image_field']);

    update_post_meta($post_id, 'my_image_field', $image_data);
}



add_action('save_post', 'save_my_custom_meta_box_data');

function your_theme_customizer_setting($wp_customize) {
    // セクションの追加
    $wp_customize->add_section( 'dropdown_options_section' , array(
'title'=> __('【KG】職種カテゴリ', 'your_theme' ),
        'priority'   => 30,
    ) );

    // 設定とコントロールの追加
    for ($i = 1; $i <= 20; $i++) {
        $wp_customize->add_setting( 'dropdown_option_'.$i , array(
            'default'     => '',
            'transport'   => 'refresh',
        ) );

        $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dropdown_option_'.$i, array(
'label'=> __('職種カテゴリ'.$i, 'your_theme' ),
            'section'    => 'dropdown_options_section',
            'settings'   => 'dropdown_option_'.$i,
        ) ) );
    }
}
add_action( 'customize_register', 'your_theme_customizer_setting' );


function your_theme_customizer_reserve($wp_customize){
	$wp_customize->add_section('reserve_section', array(
	'title'=>__('【KG】予約リンク','your_theme'),
	'priority' =>31,));
	$reserve_corners=['予約完了分数','電話番号','営業日・営業時間','予約先URL'];
	foreach($reserve_corners as $reserve_corner){
		$wp_customize->add_setting($reserve_corner, array(
		  'default' => '',
		'transport'=>'refresh',
		)
		
		);
		$wp_customize ->add_control( new WP_Customize_control($wp_customize, $reserve_corner, array(
'label' => __($reserve_corner, 'your_theme'),
			'section'  => 'reserve_section',
			'settings' =>$reserve_corner,
		)));
	}
}

add_action('customize_register', 'your_theme_customizer_reserve');


function your_theme_customizer_setting2($wp_customize) {
    // セクションの追加
    $wp_customize->add_section( 'dropdown_options_section2' , array(
'title'=> __('【KG】雇用形態', 'your_theme' ),
        'priority'   => 30,
    ) );

    // 設定とコントロールの追加
    for ($i = 1; $i <= 10; $i++) {
        $wp_customize->add_setting( 'dropdown_option2_'.$i , array(
            'default'     => '',
            'transport'   => 'refresh',
        ) );

        $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'dropdown_option2_'.$i, array(
'label'=> __('雇用形態'.$i, 'your_theme' ),
            'section'    => 'dropdown_options_section2',
            'settings'   => 'dropdown_option2_'.$i,
        ) ) );
    }
}
add_action( 'customize_register', 'your_theme_customizer_setting2' );


function your_theme_customize_register( $wp_customize ) {
    // セクションの追加
    $wp_customize->add_section( 'your_image_upload' , array(
'title'=> __('【KG】ロゴ', 'your_theme' ),
        'priority'   => 30,
    ) );

    // 設定の追加
    $wp_customize->add_setting( 'your_image_setting' , array(
        'default'     => '',
        'transport'   => 'refresh',
    ) );

    // コントロールの追加
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'your_image_setting', array(
        'label'        => __( '画像アップロード', 'your_theme' ),
        'section'    => 'your_image_upload',
        'settings'   => 'your_image_setting',
    ) ) );
}
add_action( 'customize_register', 'your_theme_customize_register' );

function your_theme_customize_title($wp_customize){
	$wp_customize -> add_section('title_customize', array(
	'title' => __('【KG】タイトル','your_theme'),
		'priority' => 1,
		
	));
	
	$wp_customize -> add_setting('title_input' , array(
	'default' => '',
	'transport' => 'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'title_input', array(
	'label' =>__('サイトタイトル', 'your_theme'),
	'section' => 'title_customize',
	'settings' => 'title_input',
	
	)));
	
	$wp_customize -> add_setting('title_over_input' , array(
	'default' => '',
	'transport' => 'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'title_over_input', array(
	'label' =>__('サイトタイトル上', 'your_theme'),
	'section' => 'title_customize',
	'settings' => 'title_over_input',
	
	)));

	$wp_customize -> add_setting('title_under_input' , array(
	'default' => '',
	'transport' => 'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'title_under_input', array(
	'label' =>__('サイトタイトル下', 'your_theme'),
	'section' => 'title_customize',
	'settings' => 'title_under_input',
	
	)));
}

add_action('customize_register', 'your_theme_customize_title');

function your_theme_customize_topcontent($wp_customize){
	$wp_customize ->add_section('apeal_contents1',array(
	'title'=>__('【KG】トップコンテンツ','your_theme'),
	'priority'=>2,
	));
	
	$wp_customize ->add_setting('apeal_content1' , array(
	'default'=>'',
	'transport'=>'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'apeal_content1', array(
	'label'=>__('アピールコンテンツ1' , 'your_theme'),
	'section' => 'apeal_contents1',
		'settings'=> 'apeal_content1',
		
	)));
	
	$wp_customize ->add_setting('apeal_content2' , array(
	'default'=>'',
	'transport'=>'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'apeal_content2', array(
	'label'=>__('アピールコンテンツ2' , 'your_theme'),
	'section' => 'apeal_contents1',
		'settings'=> 'apeal_content2',
		
	)));
	
		$wp_customize ->add_setting('apeal_content3' , array(
	'default'=>'',
	'transport'=>'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'apeal_content3', array(
	'label'=>__('アピールコンテンツ3・1行目' , 'your_theme'),
	'section' => 'apeal_contents1',
		'settings'=> 'apeal_content3',
		
	)));
	
		$wp_customize ->add_setting('apeal_content4' , array(
	'default'=>'',
	'transport'=>'refresh',
	));
	
	$wp_customize ->add_control(new WP_Customize_Control ($wp_customize, 'apeal_content4', array(
	'label'=>__('アピールコンテンツ3・2行目' , 'your_theme'),
	'section' => 'apeal_contents1',
		'settings'=> 'apeal_content4',
		
	)));
	
$wp_customize->add_setting( 'apeal_content_image' , array(
        'default'     => 'https://cdn.pixabay.com/photo/2023/04/11/16/12/sea-7917683_960_720.jpg',
        'transport'   => 'refresh',
    ) );

    // コントロールの追加
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'apeal_content_image', array(
'label'=> __( '背景画像', 'your_theme' ),
        'section'    => 'apeal_contents1',
        'settings'   => 'apeal_content_image',
    ) ) );
	
}
add_action('customize_register', 'your_theme_customize_topcontent');


/* -------------------------------------------------------------
	ログイン画面のロゴ変更
-------------------------------------------------------------- */
function login_logo() {
	echo '<style type="text/css">
		.login h1 a {
			background-image: url('.esc_url(get_theme_mod('your_image_setting')).');
			width: 300px;
			height: 200px;
			background-size: contain;
			background-position: center center;
		}
		</style>';
  }
add_action('login_head', 'login_logo');

function mytheme_block_scripts() {
    wp_enqueue_script(
        'mytheme-block',
        get_template_directory_uri() . '/my-block/block.js',
        array( 'wp-blocks', 'wp-editor' ),
        true
    );
}
add_action( 'enqueue_block_editor_assets', 'mytheme_block_scripts' );


/**
 * Start!
 */
new \Arkhe();
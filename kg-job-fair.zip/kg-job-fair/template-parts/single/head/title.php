<?php
/**
 * 投稿タイトル
 */
?>
<div class="p-entry__title c-pageTitle">
	<h1 class="c-pageTitle__main"><?php the_title(); ?></h1>
</div>

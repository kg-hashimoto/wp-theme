import lazySizes from 'lazysizes';
import 'lazysizes/plugins/aspectratio/ls.aspectratio';
import 'lazysizes/plugins/unveilhooks/ls.unveilhooks';

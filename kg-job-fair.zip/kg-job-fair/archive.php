<?php
/**
 * アーカイブページ用テンプレート
 */
 ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?> <?php Arkhe::root_attrs(); ?>>
<head>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, viewport-fit=cover">
<?php
	wp_head();
	$setting = Arkhe::get_setting(); // SETTING取得
?>
	
	<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
	
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.4.0/css/all.css">
</head><div id="wrapper" class="l-wrapper">

	<div id="content" class="l-content">
		<?php do_action( 'arkhe_start_content' ); // テーマ側でも使用 ?>
		<div class="l-content__body l-container">
	<main id="main_content" class="<?php Arkhe::main_class(); ?>" style="width:100%;">

<style>

	.l-header{
		background:rgba(255,255,255,0);
	}


</style>
	<script>
	$(function(){
		const faqposition = $('#faq').position();
		const faqheight =  document.getElementById('faq').clientHeight;
		const y =faqposition.top;
		console.log(y);
		console.log(faqheight);
		console.log(window.outerHeight);
		$(window).on("scroll",function(){
			if($(window).scrollTop() > 300){
				$("#my_gnav").fadeIn();

			}else{
			$("#my_gnav").fadeOut();
			}
			
					if($(window).scrollTop() > 500  && ( ($(window).scrollTop() + window.outerHeight) <( y+ (faqheight/2 ) ) ) ){

				$(".reserve-corner").fadeIn();
			}else{
			$(".reserve-corner").fadeOut();
			}
		});

		
	});

	</script>
		
	<div class ="topcontent">
		<div class="white-base"></div>
		<div style="height:60px;"></div>
       <h2><?php echo get_theme_mod('title_over_input' , ''); ?></h2>
	   <h1><?php echo get_theme_mod('title_input','タイトルなし'); ?></h1>
		<h2><?php echo get_theme_mod('title_under_input', ''); ?></h2>
		<?php
$current_term = get_queried_object();
$term_id = $current_term->term_id;

// カスタムフィールドの値を取得
$realoronline = get_term_meta($term_id, 'my_custom_category', true);
$custom_field_value = get_term_meta($term_id, 'my_custom_field', true);
$custom_second_field_value = get_term_meta($term_id, 'my_custom_second_field', true);
		$custom_third_field_value = get_term_meta($term_id, 'my_custom_third_field', true);
$custom_date_value = get_term_meta($term_id, 'my_custom_date', true);
$custom_time_value = get_term_meta($term_id, 'my_custom_time', true);
$custom_second_time_value = get_term_meta($term_id, 'my_custom_second_time', true);
$custom_dropdown_value = get_term_meta($term_id, 'my_custom_dropdown_field', true);
$dtitle=get_term_meta($term_id, 'my_custom_dtitle', true);
$title1=get_term_meta($term_id,'my_custom_title1',true);
$detail1=get_term_meta($term_id,'my_custom_detail1',true);
$title2=get_term_meta($term_id,'my_custom_title2',true);
$detail2=get_term_meta($term_id,'my_custom_detail2',true);
$image1=get_term_meta($term_id,'my_image1_field',true);
$image2=get_term_meta($term_id,'my_image2_field',true);

$weekdays_ja = array('日', '月', '火', '水', '木', '金', '土');

// 日付と時間を整形
if (!empty($custom_date_value)) {
    $weekday = date('w', strtotime($custom_date_value));
    $formatted_date = date('n/j', strtotime($custom_date_value)) . '(' . $weekdays_ja[$weekday] . ')';
} else {
    $formatted_date = '';
}
$formatted_time = !empty($custom_time_value) ? date('H:i', strtotime($custom_time_value)) : '';
$formatted_second_time = !empty($custom_second_time_value) ? date('H:i', strtotime($custom_second_time_value)) : '';

// カスタムフィールドの値を表示
echo '<table style="width:calc(100% - 30px);margin-left:auto;margin-right:auto;position:relative;z-index:5;margin-top:30px;max-width:700px;text-align:center" bordercolor="#000000">';


echo '<tr><td style="background-color:skyblue;font-weight:600;font-size:1.3rem">開催日</td><td style="background-color:white;font-size:1.3rem">'.$formatted_date . '</td></tr>';
echo '<tr><td style="background-color:skyblue;font-weight:600;">時間</td><td style="background-color:white">'.$formatted_time . ' ～ ' . $formatted_second_time.'</td></tr>';
echo '<tr><td style="background-color:skyblue;font-weight:600;">';
if ($custom_dropdown_value == 'option1') {
echo '<p>会場</p>';
} elseif ($custom_dropdown_value == 'option2') {
echo '<p>オンラインツール名</p>';
}
echo '</td><td style="background-color:white;">';
		// ドロップダウンの選択肢を表示

echo strip_tags($custom_field_value);
if ($custom_dropdown_value == 'option1'){
echo '&nbsp<a href="';
echo $custom_second_field_value;
echo '">[地図を見る]</a>';
}
echo '</td></tr>';



echo '</table><br><br>';
echo $custom_third_field_value;		
?>
	 
	</div>
	<style>
     .topcontent{
		width:100%;
		height:600px;
		background-image:url("<?php echo esc_url(get_theme_mod('apeal_content_image','https://cdn.pixabay.com/photo/2023/04/11/16/12/sea-7917683_960_720.jpg')) ?>");
		 
		background-repeat: no-repeat;
		background-position: center center;
		background-size: cover;
		position:relative;
	}
		.white-base{
			position:absolute;
			background-color:white;
			width:100%;
			height:600px;
			top:0;
			left:0;
			z-index:0;
			opacity:0.5;
		}
	 .topcontent h1, .topcontent h2{
		color:#06519A;
        text-align:center;
		 position:relative;
		 z-index:1;
	 }
	 .topcontent h1{
		font-size:5rem;
		 letter-spacing:0.5rem;
		 font-weight:800;
line-height:1;
	 }
	 .topcontent h2{
		font-size:2.5rem;
		 line-height:1;
		 border-bottom:none;


		
	 }
		.topcontent h2:after{
			display:none;
			opacity:0;
			background-color:rgba(0,0,0,0);
		}
	 .top-futures{
		margin-top:40px;
		text-align:center;
		 position:relative;
		 z-index:1;
	 }
	 .top-future{
		display:inline-block;
		width:31%;
		max-width:250px;
		height:80px;
		background-color:white;
		text-align:center;
		vertical-align:top;
		border-radius:40px;
		margin-left:17px;
		margin-right:17px;
		font-weight:600;
		color:#06519A;
	    font-size:25px;
	 }
	 .top-future span{
		line-height:80px;
	 }
	 .twoline{
		line-height:20px;
		padding-top:20px;
		font-size:20px;
	 }


	</style>



		<br><br><h2 style="margin-top:60px;" id="all-company">参加企業一覧</h2>
		<style></style>
 <?php
        // カテゴリーに属する投稿を取得
        if (have_posts()) :
            $accordion_items = array();
            for ($i = 1; $i <= 16; $i++) {
                $accordion_items["item$i"] = array();
            }

            while (have_posts()) : the_post();
                // ドロップダウンフィールドの値を取得
$dropdown_field1 = get_post_meta(get_the_ID(), '業種カテゴリ1', true);
$dropdown_field2 = get_post_meta(get_the_ID(), '業種カテゴリ2', true);
$dropdown_field3 = get_post_meta(get_the_ID(), '業種カテゴリ3', true);
$open2 = get_post_meta(get_the_ID(), '公開設定2', true);
$open3 = get_post_meta(get_the_ID(), '公開設定3', true);
		


                // アコーディオンアイテムに投稿を追加
                if ($dropdown_field1) {
                    $accordion_items[$dropdown_field1][] = get_post();
                }
                if ($dropdown_field2 && $open2 == 'option_2' && !($dropdown_field2==$dropdown_field1) ) {
                    $accordion_items[$dropdown_field2][] = get_post();
                }
                if ($dropdown_field3 && $open3 == 'option_2' && !($dropdown_field3==$dropdown_field1)&& !($dropdown_field3==$dropdown_field2) ) {
                    $accordion_items[$dropdown_field3][] = get_post();
                }
            endwhile;

            // アコーディオンの表示
            foreach ($accordion_items as $item_key => $item_posts) :
                if (!empty($item_posts)) :
        ?>

        <div class="accordion-item">
           <!-- <div class="accordion-header"> -->
            <details><summary>    <h3 style="display:inline;margin-left:0;border-left:none;"><?php 
					if($item_key =='option_1'){
						echo get_theme_mod('dropdown_option_1', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_2'){
						echo get_theme_mod('dropdown_option_2', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_3'){
						echo get_theme_mod('dropdown_option_3', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_4'){
						echo get_theme_mod('dropdown_option_4', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_5'){
						echo get_theme_mod('dropdown_option_5', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_6'){
						echo get_theme_mod('dropdown_option_6', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_7'){
						echo get_theme_mod('dropdown_option_7', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_8'){
						echo get_theme_mod('dropdown_option_8', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_9'){
						echo get_theme_mod('dropdown_option_9', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_10'){
						echo get_theme_mod('dropdown_option_10', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_11'){
						echo get_theme_mod('dropdown_option_11', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_12'){
						echo get_theme_mod('dropdown_option_12', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_13'){
						echo get_theme_mod('dropdown_option_13', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_14'){
						echo get_theme_mod('dropdown_option_14', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_15'){
						echo get_theme_mod('dropdown_option_15', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_16'){
						echo get_theme_mod('dropdown_option_16', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_17'){
						echo get_theme_mod('dropdown_option_17', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_18'){
						echo get_theme_mod('dropdown_option_18', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_19'){
						echo get_theme_mod('dropdown_option_19', '職種カテゴリが設定されていません');
					}elseif($item_key=='option_20'){
						echo get_theme_mod('dropdown_option_20', '職種カテゴリが設定されていません');
					}
					
					
					
					
					
					?>
				</h3></summary>
				<style>
					.accordion-item{
						width:calc(100% - 50px);

						margin: 0 auto;
					}
					.accordion-item summary{
						background-color:darkblue;
						color:white;
						padding-left:30px;
						padding-right:50px;
						padding-top:10px;
						padding-bottom:10px;
						border:solid gray 1px;
						border-radius:30px;
						font-size:1rem;
					}
					.accordion-item h3{
						font-size:1rem;
					}
					.accordion-item details{
						margin-top:2px;
					}
				</style>
            <!--</div> -->
            <div class="accordion-content">
                <?php
                foreach ($item_posts as $item_post) :
                    setup_postdata($GLOBALS['post'] =& $item_post);
$company_name = get_post_meta(get_the_ID(), '企業名', true);
$company_district = get_post_meta(get_the_ID(), '地区', true);
$rec1_style=get_post_meta(get_the_ID(), '雇用形態1', true);
$rec1_name=get_post_meta(get_the_ID(), '業種1', true);
$rec1_place=get_post_meta(get_the_ID(), '勤務地1', true);
$rec2_style=get_post_meta(get_the_ID(), '雇用形態2', true);
$rec2_name=get_post_meta(get_the_ID(), '業種2', true);
$rec2_place=get_post_meta(get_the_ID(), '勤務地2', true);
$rec3_style=get_post_meta(get_the_ID(), '雇用形態3', true);
$rec3_name=get_post_meta(get_the_ID(), '業種3', true);
$rec3_place=get_post_meta(get_the_ID(), '勤務地3', true);
$open2 = get_post_meta(get_the_ID(), '公開設定2', true);
$open3 = get_post_meta(get_the_ID(), '公開設定3', true);
$image_url = get_post_meta(get_the_ID(), 'my_image_field', true);
$main_business = get_post_meta(get_the_ID(), '主な事業内容', true);
$work_emotion = get_post_meta(get_the_ID(), '働きやすさ・やりがい', true);
?>
				<div class="post-item"><div class="company-titles"><span class="company-district"><?php echo esc_html($company_district) ?></span> <h4><a href="<?php the_permalink(); ?>"><?php echo esc_html($company_name); ?></a></h4></div><div class = "postcontent-middle">
<?php
if (!empty($image_url)){
echo '<div  class="company-image" style="background-image:url('.esc_url($image_url).')" /></div>';
}
					
					?>
<div class="rec">
<div class="rec1">【<?php if ($rec1_style == 'option_1'){
	echo get_theme_mod('dropdown_option2_1', '雇用形態が設定されていません');
}elseif($rec1_style == 'option_2'){
	echo get_theme_mod('dropdown_option2_2', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_3'){
	echo get_theme_mod('dropdown_option2_3', '雇用形態が設定されていません');
	
}elseif($rec1_style == 'option_4'){
	echo get_theme_mod('dropdown_option2_4', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_5'){
	echo get_theme_mod('dropdown_option2_5', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_6'){
	echo get_theme_mod('dropdown_option2_6', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_7'){
	echo get_theme_mod('dropdown_option2_7', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_8'){
	echo get_theme_mod('dropdown_option2_8', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_9'){
	echo get_theme_mod('dropdown_option2_9', '雇用形態が設定されていません');
	
} elseif($rec1_style == 'option_10'){
	echo get_theme_mod('dropdown_option2_10', '雇用形態が設定されていません');
	
} 
	
	
	
	?>】<?php echo esc_html($rec1_name) ; ?><br>勤務地:<?php echo esc_html($rec1_place); ?></div>	
<?php 
if ($open2 == 'option_2'){
echo '<div class="rec2">【';
if ($rec2_style == 'option_1'){
	echo '正社員';
}elseif($rec2_style == 'option_2'){
	echo '契約社員';
	
} elseif($rec2_style == 'option_3'){
	echo '派遣社員';
	
}elseif($rec2_style == 'option_4'){
	echo 'アルバイト';
	
} elseif($rec2_style == 'option_5'){
	echo 'パート';
	
} elseif($rec2_style == 'option_6'){
	echo '業務委託';
	
} elseif($rec2_style == 'option_7'){
	echo 'その他';
	
} 
echo '】';
echo esc_html($rec2_name) ;
echo '<br>勤務地:';
echo esc_html($rec2_place);
echo '</div>';
}
if ($open3 == 'option_2'){
	echo '<div class="rec3">【';
if ($rec3_style == 'option_1'){
	echo '正社員';
}elseif($rec3_style == 'option_2'){
	echo '契約社員';
	
} elseif($rec3_style == 'option_3'){
	echo '派遣社員';
	
}elseif($rec3_style == 'option_4'){
	echo 'アルバイト';
	
} elseif($rec3_style == 'option_5'){
	echo 'パート';
	
} elseif($rec3_style == 'option_6'){
	echo '業務委託';
	
} elseif($rec3_style == 'option_7'){
	echo 'その他';
	
} 
echo '】';
echo esc_html($rec3_name) ;
echo '<br>勤務地:';
echo esc_html($rec3_place);
echo '</div>';				
}
					
					
	?>	</div></div><div class="company-explain">
<?php 

$company_explain=mb_substr($main_business . $work_emotion , 0,110);
echo esc_html($company_explain);
if (mb_strlen($company_explain)==110){
	echo "...";
}
					?>
					</div>
					<a href=" <?php the_permalink(); ?> ">
						<div class="company-link">企業情報を見る&nbsp;></div>
					</a>
                
                </div>
                <?php endforeach; ?>
				</div></details>
			<style>
				.accordion-content{
					text-align:left;
					padding-left:7%;
					padding-right:7%;
				}
				.accordion-content .post-item{
					text-align:left;
					margin-top:10px;
			        margin-bottom:5px;
				}
			</style>
        </div>

        <?php
                endif;
            endforeach;
            wp_reset_postdata();
        endif;
        ?>
	</main>
<style>
@import url('https://fonts.googleapis.com/css2?family=BIZ+UDPGothic:wght@400;700&display=swap');
	@media(min-width:1000px){
		main{
			width:100%;}
		
	}
	h4{
		display:inline-block;
		line-height:25px;
		vertical-align:center;
		height:25px;
		padding-top:5px;
		vertical-align:middle;
	}
	h4 a{
		text-decoration:none;
		color:black;
	}
	.post-item{
		display:inline-block;
		width:420px;
		height:300px;
        margin-left:7px;
		margin-right:7px;
		vertical-align:top;
		position:relative;
		background-color:#EEEEEE;
		padding-left:10px;
		padding-right:10px;
	}
	.company-district{
		display:inline-block;
		width:60px;
		height:25px;
		color:white;
		background-color:orange;
		font-weight:600;
		text-align:center;
		margin-left:8px;
		vertical-align:middle;
		margin-top:6px;
	}
	.company-image{
		width:150px;
		height:130px;
		background-size:cover;
		display:inline-block;
		margin-left:5px;
	}
	.rec{
		display:inline-block;
		width:230px;
		vertical-align:top;
		margin-left:8px;
		font-size:.8em;
		font-family: 'BIZ UDPGothic', sans-serif;
		line-height:1.3;
	}
	.company-titles{
		height:40px;
		
	}
	.postcontent-middle{
		border-top:dotted gray 2px;
		border-bottom:dotted gray 2px;
		padding-top:5px;
	}
	.company-explain{
		width:100%;
		padding-top:3px;
		padding-left:5px;
		padding-right:5px;
		height:90px;

		line-height:1.15;
		font-size:0.9em;
		font-family: 'BIZ UDPGothic', monospace;
	}
	.company-link{
		width:170px;
		height:30px;
		color:white;
		font-weight:600;
		background-color:royalblue;
		line-height:30px;
		font-size:16px;
		text-align:center;
		position:absolute;
		right:5px;
		bottom:6px;
		
	}	h2{
	text-align:center;
	width:100%;
	display:inline-block;
	margin-top:10px;
	
}
	h2:after{
		content:"";
		display:block;
		width:100px;
	
		height:4px;
		margin:0 auto;
		margin-bottom:6px;
		background-color:royalblue;
	}

			</style><br><br><br><br><div style="width:100%;height:40px;"></div>
<div style="width:100%;background-color:rgba(224,243,253,1);">
			<div style="width:calc(100% - 20px);max-width:800px;margin:0 auto;">
	
		
<?php echo $detail1 ?>
	</div></div>
			<?php
// get the current taxonomy term
$term = get_queried_object();

// define query parameters
$args = array(
    'post_type' => 'my_custom_post', // your custom post type
    'posts_per_page' => -1, // or any number you need
    'tax_query' => array(
        array(
            'taxonomy' => 'my_custom_category', // your custom taxonomy
            'field' => 'slug',
            'terms' => $term->slug,
        ),
    ),
    'tag' => '説明' // your tag
);

// create a new instance of WP_Query
$the_query = new WP_Query($args);

// The Loop
if ( $the_query->have_posts() ) {
    echo '<ul>';
    while ( $the_query->have_posts() ) {
        $the_query->the_post();
echo get_the_content();
    }
    echo '</ul>';
} else {
    // no posts found
    echo '';
}

// Restore original Post Data
wp_reset_postdata();
?>
	<div class="consul-box">
		

	<h2>個別相談コーナーについて</h2>
<div class="consul">
	

<?php
  // WP_Query arguments
  $args = array(
    'post_type' => 'consul', // ここにカスタム投稿タイプの名前を入れる
    'post_status' => 'publish',
    'posts_per_page' => -1, // 全ての投稿を表示したい場合
	  'order'=>'ASC',
	  'orderby'=>'date'
  );

  // The Query
  $query = new WP_Query($args);

  // The Loop
  if($query->have_posts()) {
    while($query->have_posts()) {
      $query->the_post();
?>

<div class="post">
<img src="
  <?php
    // アイキャッチ画像
    if(has_post_thumbnail()) {
      the_post_thumbnail_url('medium');
    }
  ?>
	  " class="consul-image">  <h4 class="post-title"><?php the_title(); ?></h4> <!-- タイトル -->
  <div class="post-content"><?php the_content(); ?></div> <!-- 本文 -->
</div>

<?php
    }
    /* Restore original Post Data */
    wp_reset_postdata();
  } else {
    // no posts found
  }
?>
</div>	
			</div>
<style>
	.post{
		width: 280px;
		height: 440px;
		display: inline-block;
		vertical-align: top;
		margin-left: 20px;
		margin-right: 20px;
		text-align: left;
		
	}
	.consul{
	   width:fit-content;
		text-align: center;
		display: flex;
		flex-wrap: wrap;
		justify-content: start;
		margin:0 auto;
	   	margin-left:calc(50% - 480px);
        background-color:rgba(0,0,0,0);
	}
	.consul-box{
		width:100%;
		text-align:center;
		background-color:lightgray;
		max-width:1080px;
		margin: 20px auto;
		margin-top:100px;
		
		
	}
	.consul-box h2{
		font-size:2em;
		padding-top:20px;
		margin-bottom:15px;
	}
	.consul-box h4{
		height:auto;
	}
	</style>
			
<?php
get_footer();

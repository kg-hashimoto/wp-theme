<?php
/**
 * フロントページテンプレート
 */
get_header(); ?>
<main id="main_content" class="<?php Arkhe::main_class(); ?>">

	<style>

.l-container{
	padding-left:0;
	padding-right:0;
}
.l-article{
	max-width:1980px;
}
	</style>
	<div class ="topcontent">
		<div class="white-base"></div>
		<div style="height:110px;"></div>
       <h2><?php echo get_theme_mod('title_over_input' , ''); ?></h2>
	   <h1><?php echo get_theme_mod('title_input','タイトルなし'); ?></h1>
		<h2><?php echo get_theme_mod('title_under_input', ''); ?></h2>
	   <div class="top-futures">
		  <div class="top-future">
			<span><?php echo get_theme_mod('apeal_content1','') ?></span>
		  </div>
		  <div class="top-future">
			<span><?php echo get_theme_mod('apeal_content2','') ?></span>
		  </div>
		  <div class="top-future twoline"><span style="line-height:17px;"><?php echo get_theme_mod('apeal_content3','') ?><br><?php echo get_theme_mod('apeal_content4','') ?></span></div>
	   </div>
	 
	</div>
	<style>
     .topcontent{
		width:100%;
		height:600px;
		background-image:url("<?php echo esc_url(get_theme_mod('apeal_content_image','https://cdn.pixabay.com/photo/2023/04/11/16/12/sea-7917683_960_720.jpg')) ?>");
		 
		background-repeat: no-repeat;
		background-position: center center;
		background-size: cover;
		position:relative;
	}
		.white-base{
			position:absolute;
			background-color:white;
			width:100%;
			height:600px;
			top:0;
			left:0;
			z-index:0;
			opacity:0.5;
		}
	 .topcontent h1, .topcontent h2{
		color:#06519A;
        text-align:center;
		 position:relative;
		 z-index:1;
	 }
	 .topcontent h1{
		font-size:5.3rem;
		 letter-spacing:0.5rem;
		 font-weight:800;
line-height:1.2;
	 }
	 .topcontent h2{
		font-size:2.5rem;
		 line-height:1.2;


		
	 }
	 .top-futures{
		margin-top:40px;
		text-align:center;
		 position:relative;
		 z-index:1;
	 }
	 .top-future{
		display:inline-block;
		width:31%;
		max-width:250px;
		height:80px;
		background-color:white;
		text-align:center;
		vertical-align:top;
		border-radius:40px;
		margin-left:17px;
		margin-right:17px;
		font-weight:600;
		color:#06519A;
	    font-size:25px;
	 }
	 .top-future span{
		line-height:80px;
	 }
	 .twoline{
		line-height:20px;
		padding-top:20px;
		font-size:20px;
	 }


	</style>

	<div class="attend-company">
	<h2 id="attend-company">日程・会場</h2>
	<?php  
		// カスタムタクソノミー 'my_custom_category' のすべてのカテゴリを取得します
$categories = get_terms(array(
    'taxonomy' => 'my_custom_category',
    'hide_empty' => false,
));
// カスタムフィールドの日付でタームをソートする関数
function sort_terms_by_custom_date_field($a, $b) {
$a_date = get_term_meta($a->term_id, 'my_custom_date', true);
$b_date = get_term_meta($b->term_id, 'my_custom_date', true);

    if ($a_date == $b_date) {
        return 0;
    }

    return ($a_date < $b_date) ? -1 : 1;
}

// タームをカスタムフィールドの日付でソート
usort($categories, 'sort_terms_by_custom_date_field');

$weekdays_ja = array('日', '月', '火', '水', '木', '金', '土');

foreach ($categories as $category) {
    // カスタムフィールドの値を取得します
    $custom_dropdown_value = get_term_meta($category->term_id, 'my_custom_dropdown_field', true);
    $custom_field_value = get_term_meta($category->term_id, 'my_custom_field', true);
	$custom_third_field_value = get_term_meta($category->term_id, 'my_custom_third_field', true);
    $custom_date_value = get_term_meta($category->term_id, 'my_custom_date', true);
    $custom_time_value = get_term_meta($category->term_id, 'my_custom_time', true);
    $custom_second_time_value = get_term_meta($category->term_id, 'my_custom_second_time', true);

    // 日付と時間を整形します
    if (!empty($custom_date_value)) {
        $weekday = date('w', strtotime($custom_date_value));
        $formatted_date = date('n/j', strtotime($custom_date_value)) . '(' . $weekdays_ja[$weekday] . ')';
    } else {
        $formatted_date = '';
    }
    $formatted_time = !empty($custom_time_value) ? date('H:i', strtotime($custom_time_value)) : '';
    $formatted_second_time = !empty($custom_second_time_value) ? date('H:i', strtotime($custom_second_time_value)) : '';

    // カテゴリーページへのリンクを取得します
    $category_link = get_term_link($category);
    // カスタムフィールドの値を表示します
    echo '<div class="event">';
       // ドロップダウンの選択肢を表示します
if(strlen($custom_third_field_value)>0){
		echo '<span class="event-date">'.$custom_third_field_value . '</span><br><span class="event-time" style="opacity:0">a</span>';
		
	}else{
    echo '<span class="event-date">'.$formatted_date . '</span><br>';
    echo '<span class="event-time">'.$formatted_time . ' ～ ' . $formatted_second_time.'</span>';}
    echo '<span class="event-detail">' . $custom_field_value . '</span>';
echo '<a href="' . esc_url($category_link) . '"><div class="detaillink">詳細を見る

<i class="fa-solid fa-circle-right"></i></div></a></div>';
}
		
		?>
<style>
	.event{
		width:200px;
		height:230px;
		background-color:white;
		display:inline-block;
		vertical-align:top;
		margin:10px;
		position:relative;
		border:solid 2px darkblue;

	}	
	.event p{
		width:100%;
		height:30px;
		font-size:20px;
		font-weight:600;
		text-align:center;
		color:white;
		background-color:royalblue;
		line-height:30px;
		border-bottom:5px solid #06519A;
	}
	.event-date{
		font-size:40px;
		font-weight:600;
		text-align:center;
		width:100%;
		display:inline-block;
		margin-top:10px;
	}
	.event-time{
		display:inline-block;
		font-size:24px;
		font-weight:600;
		text-align:center;
		width:100%;
		
	}
	.event-detail{
		text-align:center;
		display:inline-block;
		font-size:14px;
		width:calc(100% - 20px);
		margin:5px auto;
		
		border-top:5px solid royalblue;
		line-height:1.1;
		padding-top:10px;
	}
	.detaillink{
		width:100%;
		position:absolute;
		bottom:0;
		text-align:center;
		font-size:24px;
		font-weight:600;
		background-color:royalblue;
		color:white;
		padding-top:5px;
		padding-bottom:5px;
	}
</style>

    </div>
	<style>
	   .attend-company{
		width:100%;
		height:auto;
		margin-top:70px;
		background-color:#DFF2FC;
		text-align:center;
				padding-top:30px;
		padding-bottom:30px;
	   }
      .attend-company h2{
		font-size:2rem;
		text-align:center;
	
	  }

	</style>


	<div class="<?php Arkhe::main_body_class(); ?>">
		<?php
			do_action( 'arkhe_start_front_main' );

			if ( is_home() ) :
				do_action( 'arkhe_before_home_content' );
				Arkhe::get_part( 'home' );
				do_action( 'arkhe_after_home_content' );
			else :
				do_action( 'arkhe_before_front_content' );
				while ( have_posts() ) :
					the_post();
					Arkhe::get_part( 'front' );
				endwhile;
				do_action( 'arkhe_after_front_content' );
			endif;

			do_action( 'arkhe_end_front_main' );
		?>
	</div>
		
	<div class="consul-box">
		

	<h2>個別相談コーナーについて</h2>
<div class="consul">
	

<?php
  // WP_Query arguments
  $args = array(
    'post_type' => 'consul', // ここにカスタム投稿タイプの名前を入れる
    'post_status' => 'publish',
    'posts_per_page' => -1, // 全ての投稿を表示したい場合
	  'order'=>'ASC',
	  'orderby'=>'date'
  );

  // The Query
  $query = new WP_Query($args);

  // The Loop
  if($query->have_posts()) {
    while($query->have_posts()) {
      $query->the_post();
?>

<div class="post">
<img src="
  <?php
    // アイキャッチ画像
    if(has_post_thumbnail()) {
      the_post_thumbnail_url('medium');
    }
  ?>
	  " class="consul-image">  <h4 class="post-title"><?php the_title(); ?></h4> <!-- タイトル -->
  <div class="post-content"><?php the_content(); ?></div> <!-- 本文 -->
</div>

<?php
    }
    /* Restore original Post Data */
    wp_reset_postdata();
  } else {
    // no posts found
  }
?>
</div>	
			</div>
<style>
	.post{
		width: 280px;
		height: 440px;
		display: inline-block;
		vertical-align: top;
		margin-left: 20px;
		margin-right: 20px;
		text-align: left;
		
	}
	.consul{
	   width:fit-content;
		text-align: center;
		display: flex;
		flex-wrap: wrap;
		justify-content: start;
		margin:0 auto;
	   	margin-left:calc(50% - 480px);
        background-color:rgba(0,0,0,0);
	}
	.consul-box{
		width:100%;
		text-align:center;
		background-color:gainsboro;
		max-width:1080px;
		margin: 20px auto;
		margin-top:100px;
		
		
	}
	.consul-box h2{
		font-size:2em;
		padding-top:20px;
		margin-bottom:15px;
	}
	</style>
</main>

<?php
get_footer();
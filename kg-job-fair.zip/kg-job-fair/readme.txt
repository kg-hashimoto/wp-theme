=== Arkhe ===
Contributors: looswebstudio
Stable tag: 3.4.3
Tested up to: 6.0
Requires at least: 5.7
Requires PHP: 7.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
A very simple theme for production templates. Customize as you like.


=== Tags ===
two-columns, one-column, right-sidebar, custom-colors, custom-menu, editor-style, responsive, responsive-layout, theme-options, block-styles, wide-blocks


== License ==
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License version 3.

The exceptions to this license are as follows:

lazysizes.js
Copyright (c) 2015 Alexander Farkas
License: MIT License, https://opensource.org/licenses/MIT
Source: https://github.com/aFarkas/lazysizes/blob/gh-pages/LICENSE


== Screenshots ==
Image used in Screenshot
    Source: https://pxhere.com/en/photo/155920
    License: Creative Commons Zero (CC0) license.
    License Url : https://pxhere.com/en/license


== Author ==
The theme built by Ryo Yamasaki (looswebstudio) at LOOS,Inc.
You can contact me at Twitter.
https://twitter.com/ddryo_loos


== Changelog ==
See https://github.com/loos/arkhe

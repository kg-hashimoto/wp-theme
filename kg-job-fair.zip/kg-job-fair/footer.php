<?php
/**
 * フッターテンプレート
 */
//if ( Arkhe::is_show_sidebar() ) get_sidebar(); // サイドバー
?>
	</div><!-- End: l-content__body -->
	<?php do_action( 'arkhe_end_content' ); ?>
</div><!-- End: l-content -->
<div class="faq" id = "faq">
<h2>よくある質問</h2>
        <?php
        $args = array(
            'post_type' => 'faq',
            'posts_per_page' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC',
        );
        $faq_query = new WP_Query($args);

        if ($faq_query->have_posts()) :
            while ($faq_query->have_posts()) : $faq_query->the_post();
        ?>

        <details>
            <summary><?php the_title(); ?></summary>
            <?php the_content(); ?>
        </details>

        <?php
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
	</div>
	<style>
		.faq{
			width:100%;
			margin-top:0px;
			padding:20px;
			padding-top:5px;
		
			
		}
		.faq details{
			width:calc(100% - 50px);
			border:solid gray 2px;
			border-radius:30px;
			font-size:1rem;
			padding:6px 20px;
			background-color:#DEF0FA;
           
			margin-bottom:5px;

		}
		.faq details summary{
			font-size:1.5rem;
			font-weight:600;
			color:black;
		}
		.faq h2{
			width:100%;
			text-align:center;
			display:inline-block;
			padding-top:30px;
		}

	</style>
<?php
	// フッター
	do_action( 'arkhe_before_footer' ); // テーマ側でも使用
	Arkhe::get_part( 'footer' );
	do_action( 'arkhe_after_footer' );

	// モーダルや固定ボタンなど
	Arkhe::get_part( 'footer/fix_btns' );
	Arkhe::get_part( 'footer/modals' );
?>
</div>
<!-- End: #wrapper-->

<div class="reserve-corner">
<span class="attention"><?php echo get_theme_mod('title_input', 'タイトルなし'); ?>の予約はこちらから</span>
	<a href="<?php get_theme_mod('予約先URL' ,'#') ?>" class="reserve-button"><span class="reserve-need">予約必須</span>&nbsp;<?php echo get_theme_mod('予約完了分数' ,'3'); ?>分で完了!予約フォームへ進む&nbsp;<i class="fa-regular fa-circle-right"></i></a>
	<span class="tel-here">お電話でのお問い合わせは<br>こちらから</span><a href="tel:<?php echo get_theme_mod('予約完了分数','1'); ?>" class="tellink"><?php echo get_theme_mod('電話番号' ,''); ?></a><span class="business-hour"><?php echo get_theme_mod('営業日・営業時間',''); ?></span>
</div>
<style>
	.reserve-corner{
		position:fixed;
		width:100%;
		height:145px;
		background-color:orange;
		bottom:0;
		text-align:center;
		display:none;
	}
	.attention{
		font-size:2rem;
		font-weight:600;
		width:100%;
		text-align:center;
		display:inline-block;
	}
	.reserve-button{
		display:block;
		width:80%;
		background-color:black;
		height:50px;
		margin:0 auto;
		color:orange;
		text-decoration:none;
		font-size:2rem;
		font-weight:600;
		border-radius:5px;
	}
	.reserve-need{
		background-color:white;
		color:black;
		padding:2px;
		margin-right:5px;
	}
	.tel-here{
		display:inline-block;
		text-align:left;
		line-height:1.1;
		margin-top:8px;
		margin-right:6px;
	}
	.tellink{
		font-size:2.7rem;
		text-decoration:none;
		color:black;
		font-weight:600;
		display:inline-block;
		vertical-align:top;
		line-height:50px;
	}
	.business-hour{
		display:inline-block;
		height:50px;
		line-height:50px;
		margin-left:8px;
	}
	.l-content__body{
		margin-bottom:0;
	}
</style>
	<script>
	$(function(){
		const faqposition = $('#faq').position();
		const faqheight =  document.getElementById('faq').clientHeight;
		const y =faqposition.top;
		console.log(y);
		console.log(faqheight);
		console.log(window.outerHeight);
		$(window).on("scroll",function(){

			
					if($(window).scrollTop() > 500  && ( ($(window).scrollTop() + window.outerHeight) <( y+ (faqheight/2 ) ) ) ){

				$(".reserve-corner").fadeIn();
			}else{
			$(".reserve-corner").fadeOut();
			}
		});

		
	});

	</script>
<?php  wp_footer();  ?>
</body>
</html>

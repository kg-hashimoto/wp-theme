<?php

// ウィジェットの使用状況
$is_active_footer1 = is_active_sidebar( 'footer-1' );
$is_active_footer2 = is_active_sidebar( 'footer-2' );
?>
<footer>
<div class="reserve-corner2">
<span class="attention"><?php echo get_theme_mod('title_input', 'タイトルなし'); ?>の予約はこちらから</span>
	<a href="<?php get_theme_mod('予約先URL' ,'#') ?>" class="reserve-button"><span class="reserve-need">予約必須</span>&nbsp;<?php echo get_theme_mod('予約完了分数' ,'3'); ?>分で完了!予約フォームへ進む&nbsp;<i class="fa-regular fa-circle-right"></i></a>
	<span class="tel-here">お電話でのお問い合わせは<br>こちらから</span><a href="tel:<?php echo get_theme_mod('予約完了分数','1'); ?>" class="tellink"><?php echo get_theme_mod('電話番号' ,''); ?></a><span class="business-hour"><?php echo get_theme_mod('営業日・営業時間',''); ?></span>
</div>
<style>
	.reserve-corner2{
	
		width:100%;
		height:145px;
		background-color:orange;
		bottom:0;
		text-align:center;
	    display:block;
	}

	
</style>
	<div id = "footer">
		<div class="site-title"><?php echo get_theme_mod('title_over_input', 'タイトルなし'); ?><?php echo get_theme_mod('title_input', 'タイトルなし'); ?></div>
		<div class="section1 section"><h5><a href="<?php get_site_url() ?>#about">合同企業説明会の内容</a></h5>
		<ul>
			<li><a href="<?php get_site_url() ?>.#about">合同企業面接会とは？</a></li>
			<li><a href="<?php get_site_url() ?>.#whatis">イベントの様子</a></li>
			<li><a href="<?php get_site_url() ?>.#attend-company">面接会一覧</a></li>
			</ul>
		</div><div class="section2 section"><h5><a href="<?php get_site_url() ?>.#corner">転職サポート各種コーナー</a></h5>
		<ul>
			<li><a href="<?php get_site_url() ?>.#booth">転職相談ブース</a></li>
			<li><a href="<?php get_site_url() ?>.#workout">出張ハローワーク相談コーナー</a></li>
			<li><a href="<?php get_site_url() ?>.#tour">ブースツアー</a></li>
		</ul></div><div class="section3 section"><h5>FAQ</h5>
		<ul>
			<li><a href="<?php get_site_url() ?>.#faq">よくある質問</a></li>
			<li>お問い合わせ</li>
			
			</ul></div><div class="section4 section"><h5>このサイトについて</h5>
		<ul>
			<li>プライバシーポリシー</li>
			<li>サイトマップ</li>
			<li>運営企業情報</li>
			
			</ul></div>
	</div>
	<style>
		#footer{
			width:100%;
			height:160px;
			background-color:black;
			color:white;
			text-align:center;
		}
		#footer .site-title{
			font-size:1.1rem;
		
			margin-bottom:10px;

		}
		#footer .section{
			display:inline-block;
			width:240px;
			height:110px;
			vertical-align:top;
			text-align:left;
			padding:5px;
			margin:none;
			
		}
		#footer .section1, #footer .section2 , #footer .section3{
			border-right:solid gray 1px;
		}
		#footer .section ul {
			font-size:0.8rem;
			text-decoration:none;
		}
		#footer h5{
			font-weight:500;
		}
		#footer a{
			color:white;
			text-decoration:none;
		}
	
	</style>
</footer>

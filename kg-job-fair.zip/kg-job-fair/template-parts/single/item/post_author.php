<?php
// backward compatible for ~1.4
Arkhe::get_part( 'single/foot/post_author', $args );

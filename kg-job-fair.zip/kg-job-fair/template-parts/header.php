<?php
/**
 * ヘッダー用テンプレート
 */

$move_gnav_under = Arkhe::get_setting( 'move_gnav_under' );
$logo_pos        = $move_gnav_under ? 'center' : 'left';
?>
<header id="header" class="l-header" <?php Arkhe::header_attrs( array( 'logo_pos' => $logo_pos ) ); ?>>
<!--	<?php echo esc_html( get_option( 'blogname' ) ); ?>  -->

	<div class="l-header__body l-container">
		<?php Arkhe::get_part( 'header/btn/drawer' ); ?>
		<div class="l-header__left">
		
		</div>
		
		
	<!--もともとロゴが入ってた部分	<div class="l-header__center">
			<?php Arkhe::get_part( 'header/logo' ); ?>
		</div>  -->

		
		<div class="l-header__right">
			<?php
				if ( ! $move_gnav_under ) :
					Arkhe::get_part( 'header/gnav' );
				endif;
				do_action( 'arkhe_header_right_content' );
			?>
		</div>
		<?php Arkhe::get_part( 'header/btn/search' ); ?>
		<?php Arkhe::get_part( 'header/drawer_menu' ); ?>
	</div>
</header>


<?php if ( $move_gnav_under ) : ?>
	<div class="l-headerUnder" <?php if ( Arkhe::get_setting( 'fix_gnav' ) )  echo ' data-fix="1"'; ?>>
		<div class="l-headerUnder__inner l-container">
			<?php Arkhe::get_part( 'header/gnav' ); ?>
		</div>
	</div>

<?php endif; ?>
  <div class="header-container">
	  <a href ="http://hiroshima-test.1detukureru.com/" style="width:330px;"><img src="<?php echo esc_url( get_theme_mod('your_image_setting', '')); ?>" class="logo" style="width:330px;"></a><ul class="headermenu"><a href="<?php echo site_url(); ?>#attend-company"><li>日程・会場<br><div class="menu-line"></li></a><a href="<?php echo site_url(); ?>#about"><li>説明会の内容<br><div class="menu-line"></li></a><a href="<?php echo site_url(); ?>#corner"><li>転職サポート各種コーナー<br><div class="menu-line"></li></a><a href="<?php echo site_url(); ?>#about"><li>よくある質問<br><div class="menu-line"></li></a>
	
	  </ul></div>
		<style>.header-container {
    display: flex;
    align-items: center;
  }

  .logo {
    width: 230px;
    display: inline-block;
	  margin-top:5px;
	  margin-left:5px;
  }

  .headermenu {
    display: inline-block;
    margin-left: auto;
  }

  .headermenu li {
    text-decoration: none;
    display: inline-block;
    color:black;
    padding: 10px;
	margin-left:5px;
  }
			.menu-line{
				width:50%;
				min-width:25px;
				height:3px;
				background-color:gray;
				margin: 0 auto;
	}

</style>
<script>

$('.headermenu li').hover(
function(){
	console.log("hello");
	$(this).find('.menu-line').css({
		'width':'90%'
		
	});
},function(){
	console.log("goodbye");

	$(this).find('.menu-line').css({
		'width':'50%'
		
	});
}

);
</script>